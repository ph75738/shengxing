extern const unsigned char FixEDIDVersionString[];
extern const double FixEDIDVersionNumber;
